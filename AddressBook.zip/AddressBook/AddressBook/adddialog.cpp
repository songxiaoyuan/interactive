#include "adddialog.h"

AddDialog::AddDialog(QWidget *parent)
	: QDialog(parent)
{
	ui.setupUi(this);
}

AddDialog::~AddDialog()
{

}
