/********************************************************************************
** Form generated from reading UI file 'addressbook.ui'
**
** Created by: Qt User Interface Compiler version 5.1.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDRESSBOOK_H
#define UI_ADDRESSBOOK_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddressBookClass
{
public:
    QWidget *centralWidget;
    QListWidget *addressList;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *Add;
    QPushButton *Delete;
    QSpacerItem *verticalSpacer;
    QLabel *nameLabel;
    QLabel *emailLabel;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *AddressBookClass)
    {
        if (AddressBookClass->objectName().isEmpty())
            AddressBookClass->setObjectName(QStringLiteral("AddressBookClass"));
        AddressBookClass->resize(556, 400);
        centralWidget = new QWidget(AddressBookClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        addressList = new QListWidget(centralWidget);
        addressList->setObjectName(QStringLiteral("addressList"));
        addressList->setGeometry(QRect(0, 0, 431, 192));
        verticalLayoutWidget = new QWidget(centralWidget);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(440, 0, 111, 191));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        Add = new QPushButton(verticalLayoutWidget);
        Add->setObjectName(QStringLiteral("Add"));

        verticalLayout->addWidget(Add);

        Delete = new QPushButton(verticalLayoutWidget);
        Delete->setObjectName(QStringLiteral("Delete"));

        verticalLayout->addWidget(Delete);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout->addItem(verticalSpacer);

        nameLabel = new QLabel(centralWidget);
        nameLabel->setObjectName(QStringLiteral("nameLabel"));
        nameLabel->setGeometry(QRect(10, 210, 151, 16));
        emailLabel = new QLabel(centralWidget);
        emailLabel->setObjectName(QStringLiteral("emailLabel"));
        emailLabel->setGeometry(QRect(10, 240, 151, 16));
        AddressBookClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(AddressBookClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 556, 21));
        AddressBookClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(AddressBookClass);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        AddressBookClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(AddressBookClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        AddressBookClass->setStatusBar(statusBar);

        retranslateUi(AddressBookClass);
        QObject::connect(Add, SIGNAL(clicked()), AddressBookClass, SLOT(on_addButton_clicked()));

        QMetaObject::connectSlotsByName(AddressBookClass);
    } // setupUi

    void retranslateUi(QMainWindow *AddressBookClass)
    {
        AddressBookClass->setWindowTitle(QApplication::translate("AddressBookClass", "AddressBook", 0));
        Add->setText(QApplication::translate("AddressBookClass", "\346\267\273\345\212\240", 0));
        Delete->setText(QApplication::translate("AddressBookClass", "\345\210\240\351\231\244", 0));
        nameLabel->setText(QApplication::translate("AddressBookClass", "<No item selected>", 0));
        emailLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class AddressBookClass: public Ui_AddressBookClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDRESSBOOK_H
